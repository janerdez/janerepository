## :shamrock: **cv**

[![CD][cd-shield]][cd-url]
[![EN][en-shield]][en-url]
[![RU][ru-shield]][ru-url]
[![License][license-shield]][license-url]

### My Typst CV template available in multiple languages.

<!-- MARKDOWN LINKS -->

[cd-shield]: https://img.shields.io/github/actions/workflow/status/tensorush/cv/cd.yaml?branch=main&style=for-the-badge&logo=github&label=CD&labelColor=black
[cd-url]: https://github.com/tensorush/cv/blob/main/.github/workflows/cd.yaml
[en-shield]: https://img.shields.io/badge/click-009E60?style=for-the-badge&logo=read.cv&label=en&labelColor=black
[en-url]: https://tensorush.github.io/cv/en.pdf
[ru-shield]: https://img.shields.io/badge/click-009E60?style=for-the-badge&logo=read.cv&label=ru&labelColor=black
[ru-url]: https://tensorush.github.io/cv/ru.pdf
[license-shield]: https://img.shields.io/github/license/tensorush/cv.svg?style=for-the-badge&labelColor=black
[license-url]: https://github.com/tensorush/cv/blob/main/LICENSE.md
